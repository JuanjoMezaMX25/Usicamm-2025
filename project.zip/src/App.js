import React, { useState, useEffect } from 'react';
import users from './mock/users';
import questions from './mock/questions';
import LoginForm from './components/LoginForm';
import Timer from './components/Timer';
import Question from './components/Question';
import Pagination from './components/Pagination';
import Results from './components/Results';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [examStarted, setExamStarted] = useState(false);
  const [examFinished, setExamFinished] = useState(false);
  const [selectedQuestions, setSelectedQuestions] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(0);

  const QUESTIONS_PER_PAGE = 10;
  const TOTAL_QUESTIONS = 90;
  const EXAM_DURATION = 2 * 60 * 60; // 2 horas en segundos

  const handleLogin = (credentials) => {
    const user = users.find(
      (u) => u.email === credentials.email && u.password === credentials.password
    );
    if (user) {
      setIsLoggedIn(true);
    } else {
      alert('Credenciales incorrectas');
    }
  };

  const startExam = () => {
    // Seleccionar 90 preguntas aleatorias
    const shuffled = [...questions].sort(() => 0.5 - Math.random());
    setSelectedQuestions(shuffled.slice(0, TOTAL_QUESTIONS));
    setExamStarted(true);
  };

  const handleOptionSelect = (questionId, option) => {
    setAnswers({
      ...answers,
      [questionId]: option
    });
  };

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const handleTimeUp = () => {
    finishExam();
  };

  const finishExam = () => {
    let correctAnswers = 0;
    selectedQuestions.forEach((q) => {
      if (answers[q.id] === q.answer) {
        correctAnswers++;
      }
    });
    setScore(correctAnswers);
    setExamFinished(true);
  };

  const restartExam = () => {
    setExamStarted(false);
    setExamFinished(false);
    setSelectedQuestions([]);
    setCurrentPage(1);
    setAnswers({});
    setScore(0);
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  if (!examStarted) {
    return (
      <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-lg text-center">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">Simulador de Examen</h2>
        <p className="mb-6 text-gray-700">
          El examen consta de {TOTAL_QUESTIONS} preguntas seleccionadas aleatoriamente de un banco de {questions.length} preguntas.
        </p>
        <p className="mb-6 text-gray-700">
          Tienes 2 horas para completar el examen. ¡Buena suerte!
        </p>
        <button
          onClick={startExam}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
        >
          Comenzar Examen
        </button>
      </div>
    );
  }

  if (examFinished) {
    return <Results score={score} totalQuestions={TOTAL_QUESTIONS} onRestart={restartExam} />;
  }

  const currentQuestions = selectedQuestions.slice(
    (currentPage - 1) * QUESTIONS_PER_PAGE,
    currentPage * QUESTIONS_PER_PAGE
  );

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="flex justify-between items-start mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Simulador de Examen</h2>
        <Timer initialTime={EXAM_DURATION} onTimeUp={handleTimeUp} />
      </div>

      <div className="mb-6">
        {currentQuestions.map((question) => (
          <Question
            key={question.id}
            question={question}
            selectedOption={answers[question.id]}
            onOptionSelect={(option) => handleOptionSelect(question.id, option)}
          />
        ))}
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={Math.ceil(TOTAL_QUESTIONS / QUESTIONS_PER_PAGE)}
        onPageChange={handlePageChange}
      />

      <div className="mt-6 text-center">
        <button
          onClick={finishExam}
          className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 transition-colors"
        >
          Finalizar Examen
        </button>
      </div>
    </div>
  );
};

export default App;

// DONE