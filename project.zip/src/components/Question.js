import React from 'react';

const Question = ({ question, selectedOption, onOptionSelect }) => {
  return (
    <div className="mb-8 p-6 bg-white rounded-lg shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">{question.question}</h3>
      <div className="space-y-3">
        {question.options.map((option, index) => (
          <div key={index} className="flex items-center">
            <input
              type="radio"
              id={`option-${index}`}
              name="question"
              value={option}
              checked={selectedOption === option}
              onChange={() => onOptionSelect(option)}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor={`option-${index}`} className="ml-3 text-gray-700">
              {option}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Question;