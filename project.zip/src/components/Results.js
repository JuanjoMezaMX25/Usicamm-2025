import React from 'react';

const Results = ({ score, totalQuestions, onRestart }) => {
  const percentage = Math.round((score / totalQuestions) * 100);

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-lg text-center">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Resultados del Examen</h2>
      <div className="mb-6">
        <div className="text-5xl font-bold text-blue-600 mb-2">{score}/{totalQuestions}</div>
        <div className="text-xl font-semibold text-gray-700">{percentage}%</div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-4 mb-6">
        <div
          className="bg-blue-600 h-4 rounded-full"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <button
        onClick={onRestart}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
      >
        Volver a Intentar
      </button>
    </div>
  );
};

export default Results;