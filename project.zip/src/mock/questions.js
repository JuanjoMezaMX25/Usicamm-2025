const questions = [
  {
    id: 1,
    question: "Pregunta 1: Caso: Durante el recreo, una docente observa que un alumno es rodeado y empujado por otros compañeros. La docente lo reporta con la directora. Pregunta: Según el Acuerdo 14/12/23, ¿qué paso sigue inmediatamente después de esta detección?",
    options: [
      "A) Acompañar al alumno a su casa para evitar mayores riesgos.",
      "B) Esperar a ver si el comportamiento se repite antes de actuar.",
      "C) Notificar a la autoridad competente y al cuerpo colegiado del plantel."
    ],
    answer: "C) Notificar a la autoridad competente y al cuerpo colegiado del plantel."
  },
  {
    id: 2,
    question: "Pregunta 2: ¿Cuál es el primer paso en el protocolo de actuación ante situaciones de violencia escolar?",
    options: [
      "A) Sancionar inmediatamente a los agresores",
      "B) Realizar una investigación exhaustiva del caso",
      "C) Garantizar la protección inmediata de la víctima"
    ],
    answer: "C) Garantizar la protección inmediata de la víctima"
  },
  // ... (185 preguntas más en formato compatible con React)
];

export default questions;

// DONE