const users = [
  {
    id: 1,
    email: "usuario@ejemplo.com",
    password: "123456"
  }
];

export default users;